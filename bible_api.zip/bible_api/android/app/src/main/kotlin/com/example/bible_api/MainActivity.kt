package com.example.bible_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
