import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Bible API Example'),
        ),
        body: BibleApiWidget(),
      ),
    );
  }
}

class BibleApiWidget extends StatefulWidget {
  @override
  _BibleApiWidgetState createState() => _BibleApiWidgetState();
}

class _BibleApiWidgetState extends State<BibleApiWidget> {
  // Replace this URL with the actual API endpoint
  final String apiUrl = 'https://api.scripture.api.bible/v1/bibles';

  // Replace this with your actual API key
  final String apiKey = '71fc2af4e982d618c027e1c25332f0e5';

  late List<dynamic> bibleData;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse('$apiUrl'), headers: {
      'api-key': apiKey,
    });

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, parse the data
      setState(() {
        bibleData = json.decode(response.body)['data'];
      });
    } else {
      // If the server did not return a 200 OK response,
      // throw an exception.
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: bibleData == null
          ? CircularProgressIndicator()
          : ListView.builder(
              itemCount: bibleData.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(bibleData[index]['name']),
                  subtitle: Text(bibleData[index]['abbreviation']),
                );
              },
            ),
    );
  }
}
